-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 05, 2019 at 09:02 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `express_food`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adress` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `first_name`, `last_name`, `adress`, `phone`, `email`) VALUES
(3, 'Aldo', 'Galvagni', '509 Parkway drive', 123456789, 'galvagnialdo@gmail.com'),
(4, 'Artjoms', 'Markovins', 'Liepu iela 5-19', 1235467890, 'artjoms.m@gmail.com'),
(5, 'Toms', 'Lauks', 'Bauskas iela 59', 987645321, 'lauks.toms@gmail.com'),
(6, 'Alise', 'Brinke', 'Berzkalnu iela 4-10', 978456123, 'alise.brinke@gmail.com'),
(7, 'Regina', 'Markovina', 'Liepu iela 5-19', 192834657, 'markovina.r@gmail.com'),
(8, 'Liana', 'Markovina', 'Parupes iela 12', 1924356789, 'markovina.liana@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `daily_menu`
--

DROP TABLE IF EXISTS `daily_menu`;
CREATE TABLE IF NOT EXISTS `daily_menu` (
  `dish_id` int(11) NOT NULL AUTO_INCREMENT,
  `dish_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Price` decimal(9,2) NOT NULL,
  PRIMARY KEY (`dish_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `daily_menu`
--

INSERT INTO `daily_menu` (`dish_id`, `dish_name`, `date`, `type`, `Price`) VALUES
(1, 'Beetroot salad with hearing', '2019-02-22', 'main', '10.00'),
(2, 'Baked Baltic fish with boiled potatoes', '2019-02-22', 'main', '8.00'),
(5, 'Bread pudding with whipped cream', '2019-02-22', 'dessert', '9.00'),
(6, 'Strawberry soup with vanilla ice-cream', '2019-02-22', 'dessert', '9.79'),
(7, 'Spaghetti', '2019-02-23', 'main', '10.76'),
(8, 'Barbecque ribs', '2019-02-23', 'main', '12.12'),
(9, 'Apple pie', '2019-02-23', 'dessert', '12.32'),
(10, 'Cherry pie', '2019-02-23', 'dessert', '9.84'),
(11, 'Chicken with asparagus', '2019-02-24', 'main', '12.67'),
(12, 'Beef balls in tomatoe souce', '2019-02-24', 'main', '6.56'),
(13, 'Blueberry pancakes', '2019-02-24', 'dessert', '10.89'),
(14, 'Homemade vanilla ice-cream crepes', '2019-02-24', 'dessert', '9.65'),
(15, 'Grilled Tequila Flank Steak', '2019-02-25', 'main', '13.87'),
(16, 'Goat cheese enchiladas', '2019-02-25', 'main', '9.89'),
(17, 'Peanut Butter Cookie Chocolate Dump Cake', '2019-02-25', 'dessert', '9.87'),
(18, 'Triple Lemon Cheesecake Swirl Bar', '2019-02-25', 'dessert', '8.76'),
(19, 'London Broil with Herb Butter', '2019-02-26', 'main', '9.76'),
(20, 'Lemon and Garlic roast chicken', '2019-02-26', 'main', '6.65'),
(21, 'Twix Slab Pie', '2019-02-26', 'dessert', '9.78'),
(22, 'Tres Leches Cake', '2019-02-26', 'dessert', '8.23'),
(23, 'Oven fried chicken', '2019-02-27', 'main', '8.78'),
(24, 'Chicken Cacciatore', '2019-02-27', 'main', '6.78'),
(25, 'Cream Soda Bundt Cake', '2019-02-27', 'dessert', '8.35'),
(26, 'Kitchen Sink Brownies', '2019-02-27', 'dessert', '4.50'),
(27, 'Eggplant Parmegiana', '2019-02-28', 'main', '10.25'),
(28, 'Osso Buco', '2019-02-28', 'main', '0.00'),
(29, 'Tiramisu sheet cake', '2019-02-28', 'dessert', '0.00'),
(30, 'Neapolitan Brownies', '2019-02-28', 'dessert', '0.00'),
(31, 'Chicken noodle soup', '2019-03-28', 'main', '0.00'),
(32, 'Latvian mouse', '2019-03-28', 'dessert', '0.00'),
(33, 'Jāņa siers', '2019-03-28', 'dessert', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_person`
--

DROP TABLE IF EXISTS `delivery_person`;
CREATE TABLE IF NOT EXISTS `delivery_person` (
  `delivery_person_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` int(11) NOT NULL,
  PRIMARY KEY (`delivery_person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `delivery_person`
--

INSERT INTO `delivery_person` (`delivery_person_id`, `first_name`, `last_name`, `phone_number`) VALUES
(1, 'Michael', 'Paul', 1324537822),
(2, 'Kalyd', 'Jamalay', 1325638882),
(3, 'Gigi', 'Hadid', 2111111111),
(4, 'Robert', 'Patison', 1098765432);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_details` int(11) NOT NULL,
  `delivery_person_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `order_details` (`order_details`),
  KEY `delivery_person_id` (`delivery_person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`order_id`, `order_details`, `delivery_person_id`) VALUES
(2, 3, 1),
(3, 4, 2),
(4, 5, 3),
(5, 6, 4),
(6, 7, 3),
(7, 8, 4),
(8, 9, 2);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
CREATE TABLE IF NOT EXISTS `order_details` (
  `order_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `dish_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`order_details_id`),
  KEY `dish_id` (`dish_id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_details_id`, `dish_id`, `client_id`, `quantity`, `date`) VALUES
(3, 1, 3, 3, '2019-02-22 07:18:00'),
(4, 2, 4, 4, '2019-02-22 11:21:00'),
(5, 5, 5, 6, '2019-02-22 14:24:00'),
(6, 6, 8, 5, '2019-02-22 17:34:00'),
(7, 6, 7, 2, '2019-02-22 09:00:00'),
(8, 28, 6, 10, '2019-02-28 12:00:00'),
(9, 30, 7, 6, '2019-02-28 16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_history`
--

DROP TABLE IF EXISTS `order_history`;
CREATE TABLE IF NOT EXISTS `order_history` (
  `order_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  KEY `order_id` (`order_id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_history`
--

INSERT INTO `order_history` (`order_id`, `client_id`, `date`) VALUES
(2, 3, '2019-02-22 07:18:00'),
(3, 4, '2019-02-22 11:21:00'),
(4, 5, '2019-02-22 14:24:00'),
(5, 8, '2019-02-22 17:34:00'),
(6, 7, '2019-02-22 09:00:00'),
(7, 6, '2019-02-28 12:00:00'),
(8, 7, '2019-02-27 16:00:00');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`order_details`) REFERENCES `order_details` (`order_details_id`),
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`delivery_person_id`) REFERENCES `delivery_person` (`delivery_person_id`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`dish_id`) REFERENCES `daily_menu` (`dish_id`),
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`);

--
-- Constraints for table `order_history`
--
ALTER TABLE `order_history`
  ADD CONSTRAINT `order_history_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`),
  ADD CONSTRAINT `order_history_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
